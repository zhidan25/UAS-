
		<!-- footer -->
		<div class="footer">
			<div class="container text-center">
				Copyright &copy; 2022 - Presensi Siswa
			</div>
		</div>
	</body>
</html>