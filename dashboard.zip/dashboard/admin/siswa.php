<?php
    include 'header.php'
?>

    <h1 class="text-center" style="margin-top: 100px; ">BIODATA DIRI</h1>
    <table class="text-center" style="margin-left: 350px;" border="1" cellspacing="0" cellpadding="5"width="800">
        <tr align="center" bgcolor="#1fe5d5">
            <td width="200">DATA DIRI</td>
            <td width="400">KETERANGAN</td>
            <td width="200">FOTO</td>
        </tr>
        <tr>
            <td>Nama</td>
            <td> Budi </td>
            <td rowspan="7"><img src="http://trimelive.com/wp-content/uploads/2020/12/gambar-Wa-1.png" width="200"></td>
        </tr>
        <tr>
            <td>Tempat/Tanggal Lahir</td>
            <td> PLH,12-12-2001 </td>
        </tr>
        <tr>
            <td>NIS</td>
            <td> A131 </td>
        </tr>
        <tr>
            <td>Kelas</td>
            <td> 2 </td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td> Pelaihari </td>
        </tr>
        <tr>
            <td>Status</td>
            <td> Siswa </td>
        </tr>
    </table>

<?php
    include 'footer.php'
?>