<?php
	include 'header.php'
?>

		<div style="text-align: center; margin-top: 100px;">
			<h2>JUNI 2022</h2>
			<p>1 Juni : Libur Hari Lahir Pancasila</p>
			<p>6 – 17 Juni : Penilaian Akhir Tahun (PAT)</p>
			<p>21 Juni : Rapat Pleno Kenaikan Kelas</p>
			<p>24 Juni : Tanggal Penetapan rapor semester 2</p>
			<p>24 Juni : Pembagian Rapor Semester 2</p>
			<p>27 Juni – 17 Juli 2022 : Libur Akhir Tahun Pelajaran</p>

			<h2 style="margin-top: 50px;">JUNI 2022</h2>
			<p>1 Juni : Libur Hari Lahir Pancasila</p>
			<p>6 – 17 Juni : Penilaian Akhir Tahun (PAT)</p>
			<p>21 Juni : Rapat Pleno Kenaikan Kelas</p>
			<p>24 Juni : Tanggal Penetapan rapor semester 2</p>
			<p>24 Juni : Pembagian Rapor Semester 2</p>
			<p>27 Juni – 17 Juli 2022 : Libur Akhir Tahun Pelajaran</p>

			<h2 style="margin-top: 50px;">JUNI 2022</h2>
			<p>1 Juni : Libur Hari Lahir Pancasila</p>
			<p>6 – 17 Juni : Penilaian Akhir Tahun (PAT)</p>
			<p>21 Juni : Rapat Pleno Kenaikan Kelas</p>
			<p>24 Juni : Tanggal Penetapan rapor semester 2</p>
			<p>24 Juni : Pembagian Rapor Semester 2</p>
			<p>27 Juni – 17 Juli 2022 : Libur Akhir Tahun Pelajaran</p>
		</div>

<?php
	include 'footer.php'
?>