<?php
  include 'header.php'
?>

<table class="table" border="1" cellspacing="0" 
style="margin: 250px auto; width: 600px; background-color: #145DA0; color: #fff;">
  <thead>
    <tr>
      <th scope="col">Nomor</th>
      <th scope="col">Hari</th>
      <th scope="col">Mapel</th>
      <th scope="col">Jam</th>
      <th scope="col">Guru</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Senin</td>
      <td>Matematika</td>
      <td>08.00 - 10.00</td>
      <td>Yuni</td>
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Selasa</td>
      <td>Kimia</td>
      <td>08.00 - 10.00</td>
      <td>Wahid</td>
    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Rabu</td>
      <td>Bhs.Indonesia</td>
      <td>08.00 - 10.00</td>
      <td>Yoni</td>
    </tr>
    <tr>
      <th scope="row">4</th>
      <td>Kamis</td>
      <td>Bhs.Inggris</td>
      <td>08.00 - 10.00</td>
      <td>Heri</td>
    </tr>
  </tbody>
</table>

<?php
  include 'footer.php'
?>